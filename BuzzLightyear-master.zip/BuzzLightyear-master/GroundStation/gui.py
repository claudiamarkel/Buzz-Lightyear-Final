#This is to create the GUI that will control operations with the cubesat,
#to implement commands over Bluetooth communications
import tkinter as tk
import time
import os
global time
global trialname

def submit_it():
    try:
        time=ent_time.get()
        trialname=ent_trial.get()
        print(time + '&' + trialname)
        assert os.path.exists(trialname + '/Logs/flightlog: ' + time)
        assert os.path.exists(trialname + '/Logs/commands: ' + time)
        openfiles.destroy()
    except:
        tk.Label(text="File not found - please try again!").pack()

#ask about identifying command
openfiles=tk.Tk()
openfiles.title('BuzzLightyear')
entryfield=tk.Frame(master=openfiles,relief=tk.GROOVE,borderwidth=5)
tk.Label(master=entryfield,text='Time:').grid(row=0,column=0)
ent_time=tk.Entry(master=entryfield)
ent_time.grid(row=0,column=1)
tk.Label(master=entryfield,text='Trial:').grid(row=1,column=0)
ent_trial=tk.Entry(master=entryfield)
ent_trial.grid(row=1,column=1)
entryfield.pack()
submit=tk.Frame(master=openfiles,borderwidth=5)
tk.Button(master=submit,text="Submit",command=submit_it).pack()
#,command=testfile(ent_trial.get(),ent_time.get())) print(ent_time.get() + '&' + ent_trial.get())
submit.pack()
openfiles.mainloop()
main=tk.Tk()
big=tk.Frame(master=main,borderwidth=10)
bottom=tk.Frame(master=main,relief='raised',borderwidth=5)
big.grid(row=0)
bottom.grid
main.mainloop()
