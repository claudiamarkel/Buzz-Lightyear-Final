import time
import picamera
from PIL import Image

camera = picamera.PiCamera() #initialize PiCamera

def takepicture(tag):
    camera.resolution = (1000,1000) #set (width, height) resolution of camera


    name = "Input"
    count = 1
    t = time.strftime("_%H:%M:%S")      # current time string
    imgname = ("img-"+str(tag)+"-unc.jpg")

    camera.capture(imgname, format = 'jpeg', quality = 10)
    IMG = Image.open(str(imgname))
    IMG = IMG.save("img-"+str(tag)+".jpg", optimize = True, quality = 60)
    return