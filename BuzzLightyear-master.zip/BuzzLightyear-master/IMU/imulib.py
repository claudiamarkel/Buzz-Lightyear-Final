import time
import board
import busio
import adafruit_fxos8700 # This is the library for the accelerometer and the magnetometer 
import adafruit_fxas21002c # This is the library for the gyroscope.
import math
import numpy

# Initializing I2C bus and device.
i2c = busio.I2C(board.SCL, board.SDA)
sensor1 = adafruit_fxos8700.FXOS8700(i2c)
sensor2 = adafruit_fxas21002c.FXAS21002C(i2c)

# Optionally create the sensor with a different accelerometer range (the
# default is 2G, but you can use 4G or 8G values):
# sensor = adafruit_fxos8700.FXOS8700(i2c, accel_range=adafruit_fxos8700.ACCEL_RANGE_4G)
# sensor = adafruit_fxos8700.FXOS8700(i2c, accel_range=adafruit_fxos8700.ACCEL_RANGE_8G)

# Optionally create the gyroscope with a different gyroscope range (the
# default is 250 DPS, but you can use 500, 1000, or 2000 DPS values):
# sensor = adafruit_fxas21002c.FXAS21002C(i2c, gyro_range=adafruit_fxas21002c.GYRO_RANGE_500DPS)
# sensor = adafruit_fxas21002c.FXAS21002C(i2c, gyro_range=adafruit_fxas21002c.GYRO_RANGE_1000DPS)
# sensor = adafruit_fxas21002c.FXAS21002C(i2c, gyro_range=adafruit_fxas21002c.GYRO_RANGE_2000DPS)


# Main loop will read the value of every sensory every second.

def getIMU(sensor1, sensor2):
    # Read acceleration & magnetometer.
    accel_x, accel_y, accel_z = sensor1.accelerometer
    mag_x, mag_y, mag_z = sensor1.magnetometer
    # Read gyroscope.
    gyro_x, gyro_y, gyro_z = sensor2.gyroscope
    
    #Gives Pitch Data then decides which quadrant the arctan value is and adds/subtracts to give a final output in degrees
    pitch = 180 * numpy.arctan2(accel_x, (accel_y*accel_y + accel_z*accel_z)**0.5)/numpy.pi
    if accel_x >= 0 and accel_z >= 0 : 
        pass
    elif accel_z <= 0 and accel_x >= 0 :
        pitch = 180 - pitch
    elif accel_z <= 0 and accel_x < 0 :
        pitch = 180 - pitch
    elif accel_z >= 0 and accel_x <= 0 :
        pitch = pitch + 360
     
    roll = (-180) * numpy.arctan2(accel_y, (accel_x*accel_x + accel_z*accel_z)**0.5)/numpy.pi
    if accel_z >= 0 and accel_y < 0:
        pass
    if accel_z <= 0 and accel_y < 0:
        roll = 180 - roll
    if accel_z <= 0 and accel_y > 0:
        roll = 180 - roll
    if accel_z > 0 and accel_y >= 0:
        roll = roll + 360
    
    roll_rad = roll*math.pi/180
    pitch_rad = pitch*math.pi/180
    
    mag_x_comp1 = mag_x*math.cos(pitch_rad) + mag_y*math.sin(roll_rad)*math.sin(pitch_rad) + mag_z*math.cos(roll_rad)*math.sin(pitch_rad)
    mag_y_comp1 = mag_y * math.cos(roll_rad) - mag_z * math.sin(roll_rad)
                                                                
    yaw = 180 * numpy.arctan2(-mag_y_comp1, mag_x_comp1)/ numpy.pi
    if yaw < 0: yaw += 360
    return yaw

    
    
