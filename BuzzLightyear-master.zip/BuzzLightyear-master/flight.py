import os
import re
import time
import math
import serial
import threading
import board
import busio
import adafruit_fxos8700
import adafruit_fxas21002c

from Camera import CameraScript as camera
from IMU import imulib as imu
import bluecom as b

spinDirection = 1 # 1 or -1 depending on IMU orientation DO NOT USE BROKEN

port = "/dev/rfcomm0"

# Initializing I2C bus and device.
i2c = busio.I2C(board.SCL, board.SDA)
sensor1 = adafruit_fxos8700.FXOS8700(i2c)
sensor2 = adafruit_fxas21002c.FXAS21002C(i2c)

print('Waiting for connection...')
s = serial.Serial(port)
print('Connected on '+s.name)

b.getNext(s)

# send int 1
# ok = recv int
# if not ok: power down
# take test.jpg
# send test.jpg
# ok = recv int
# if not ok: send error, power down
# send imu readings
# ok = recv int
# if not ok: send error, power down

startTime = time.time()

sciTarget = 9   # how many images we want
nextTheta = 0   # next point we'll take an image
thetaStep = 120 # how much to space out images, prob 120
sciCount = 0    # how many images we've taken
telemPacket = 0

lastTelem = 0
telemStep = 10

theta = 0
orbitCount = 0

#os.system("touch success.succ")

def sciThread():
	global theta
	global thetaStep
	global nextTheta
	global sciCount
	global sciTarget
	global telemPacket
	global time
	global orbitCount
	
	while True:
		theta = 360-imu.getIMU(sensor1, sensor2)
		telemPacket = theta
		#print(theta)
		tick = theta > nextTheta and theta < nextTheta+20
		
		if tick and sciCount < sciTarget:
			print("science!")
			target = int((theta % 360) / 120)
			camera.takepicture(str(orbitCount)+"-"+chr(ord('A')+target))
			sciCount += 1
		if tick:
			nextTheta += thetaStep*spinDirection
			if nextTheta*spinDirection > 360:
				nextTheta -= 360*spinDirection
				orbitCount += 1
		
		

#		if time.time() > startTime + 600:
			# send exit confirmation
#			exit()

def sendThread():
	global lastTelem
	global telemStep
	global time
	global telemPacket
	
	while True:
		if time.time() > lastTelem+telemStep:
		#	print("xmit")
			lastTelem = time.time()
			b.sendKeyedTelem(s, telemPacket)
		# list images in image dir
		list = os.listdir('.')
		for f in list:
			if bool(re.search("img-.-.\.jpg", f)):
				b.sendKeyedFile(s, f)
				os.system("rm "+f)
	
def recvThread():
	global sciTarget
	global nextTheta
	
	while True:
		# get commands
		pass


sci  = threading.Thread(target=sciThread, args=())
send = threading.Thread(target=sendThread, args=())
recv = threading.Thread(target=recvThread, args=())

sci.start()
send.start()
recv.start()

while True:
	pass
