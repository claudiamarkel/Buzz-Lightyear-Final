#taken from github
#sensor_calc.py
import time
import numpy as np
import adafruit_fxos8700
import adafruit_fxas21002c
import time
import os
import board
import busio

i2c = busio.I2C(board.SCL, board.SDA)
sensor1 = adafruit_fxos8700.FXOS8700(i2c)
sensor2 = adafruit_fxas21002c.FXAS21002C(i2c)


def roll_am(accelX,accelY,accelZ):
    roll= (180/np.pi)*np.arctan2(accelX, (accelY**2 + accelZ**2)**(1/2))
    if accelZ >= 0 and accelY < 0:
        pass
    if accelZ <= 0 and accelY < 0:
        roll = 180 - roll
    if accelZ <= 0 and accelY > 0:
        roll = 180 - roll
    if accelZ > 0 and accelY >= 0:
        roll = roll + 360
    return roll

def pitch_am(accelX,accelY,accelZ):
    pitch= (180/np.pi)*np.arctan2(accelY, (accelX**2 + accelZ**2)**(1/2))
    if accelX >= 0 and accelZ >= 0 : 
        pass
    elif accelZ <= 0 and accelX >= 0 :
        pitch = 180 - pitch
    elif accelZ <= 0 and accelX < 0 :
        pitch = 180 - pitch
    elif accelZ >= 0 and accelX <= 0 :
        pitch = pitch + 360
    return pitch

def yaw_am(accelX,accelY,accelZ,magX,magY,magZ):
    pitch = (np.pi/180)*pitch_am(accelX,accelY,accelZ)
    roll = (np.pi/180)*roll_am(accelX,accelY,accelZ)
    mag_x = magX*np.cos(pitch) + magY*np.sin(roll)*np.sin(pitch) + magZ*np.cos(roll)*np.sin(pitch)
    mag_y = magY*np.cos(roll) - magZ *np.sin(roll)
    return (180/np.pi)*np.arctan2(-mag_y, mag_x)

def roll_gy(prev_angle, delT, gyroY):
    return prev_angle +gyroY*delT
def pitch_gy(prev_angle, delT, gyroX):
    return prev_angle +gyroX*delT
def yaw_gy(prev_angle, delT, gyroZ):
    return prev_angle +gyroZ*delT

def calibrate_mag():
    delta = 10
    t_s = time.time()
    xs = []
    ys = []
    zs = []
    print("Preparing to calibrate magnetometer. Please wave around.")
    time.sleep(3)
    print("Calibrating...")
    while time.time() < t_s + delta:
       magX, magY, magZ = sensor1.magnetometer
       xs.append(magX)
       ys.append(magY)
       zs.append(magZ)
    print("Calibration complete.")
    return [(max(xs)+min(xs))/2, (max(ys)+min(ys))/2, (max(zs)+min(zs))/2]

def set_initial(offset):
    print("Preparing to set initial angle. Please hold the IMU still.")
    time.sleep(3)
    print("Setting angle...")
    accelX, accelY, accelZ = sensor1.accelerometer #m/s^2
    magX, magY, magZ = sensor1.magnetometer #gauss
    #Calibrate magnetometer readings
    magX = magX - offset[0]
    magY = magY - offset[1]
    magZ = magZ - offset[2]
    roll = roll_am(accelX, accelY,accelZ)
    pitch = pitch_am(accelX,accelY,accelZ)
    yaw = yaw_am(accelX,accelY,accelZ,magX,magY,magZ)
    print("Initial angle set.")
    return [roll,pitch,yaw]

def calibrate_gyro():
    print("Preparing to calibrate gyroscope. Put down the board and do not touch it.")
    time.sleep(3)
    print("Calibrating...")
    delta = 30
    t_s = time.time()
    xs = []
    ys = []
    zs = []
    while time.time () < t_s + delta:
        gyroX, gyroY, gyroZ = sensor2.gyroscope
        xs.append(gyroX * 180/np.pi)
        ys.append(gyroY * 180/np.pi)
        zs.append(gyroZ * 180/np.pi)
    print("Calibration complete.")
    return [(max(xs)+min(xs))/2, (max(ys)+min(ys))/2, (max(zs)+min(zs))/2]
