#This is to create the GUI that will control operations with the cubesat,
#to implement commands over Bluetooth communications
import tkinter as tk
import Image
import time
import os

os.chdir('../')
path = os.getcwd()
datapath = path + '/BuzzData/' + trialname
os.chdir('/BuzzLightyear')

def git_push():
    try:
        os.chdir('../')
        global path
        global datapath
        path = os.getcwd()
        datapath = path + '/BuzzData/' + trialname
        os.chdir(datapath)
        os.system("git add .")
        os.system('git commit -m \"Added new files in ' + trialname)
        print('made the commit')
        os.system('git pull')
        os.system('git push origin master')
        print('pushed changes')
        os.chdir('/BuzzLightyear')
    except:
        print('Couldn\'t upload to git')

def submit_it():
    try:
        global time
        global trialname
        global flightlog
        global commands
        time=ent_time.get()
        trialname=ent_trial.get()
        flightlog = datapath + '/Logs/flightlog:' + time + '.txt'
        commands= datapath + '/Commands/commands:' + time + '.txt'
        assert os.path.exists(commands)
        assert os.path.exists(flightlog)
        openfiles.destroy()
    except:
        tk.Label(text="File not found - please try again!").pack()

def open_cmd():
    cmd.destroy()
    command=tk.Entry(master=bottom)
    command.grid(row=0,column=0)
    cmd_submit=tk.Button(master=bottom,text='Send it',command=subcmd).grid(row=0,column=1)
    cancel_cmd=tk.Button(master=bottom,text='Cancel',command=rm_cmd).grid(row=0,column=2)

def rm_cmd():
    command.destroy()
    cmd_submit.destroy()
    cmd=tk.Button(master=bottom,text='Send a Command',command=open_cmd).grid(row=0)

def subcmd():
    newcmd=command.get()
    filecmd=open(commands,'a+')
    filecmd.write(newcmd)
    filecmd.close()
    git_push()
    rm_cmd()
    sent=tk.Label(master=bottom,text='Sent!').grid(row=1)
    time.sleep(5)
    sent.destroy()

#ask about identifying command
openfiles=tk.Tk()
openfiles.title('BuzzLightyear')

entryfield=tk.Frame(master=openfiles,relief=tk.GROOVE,borderwidth=5)
tk.Label(master=entryfield,text='Time:').grid(row=0,column=0)
ent_time=tk.Entry(master=entryfield)
ent_time.grid(row=0,column=1)
tk.Label(master=entryfield,text='Trial:').grid(row=1,column=0)
ent_trial=tk.Entry(master=entryfield)
ent_trial.grid(row=1,column=1)
entryfield.pack()

submit=tk.Frame(master=openfiles,borderwidth=5)
tk.Button(master=submit,text="Submit",command=submit_it).pack()
submit.pack()

openfiles.mainloop()

main=tk.Tk()
big=tk.Frame(master=main,borderwidth=10)
bottom=tk.Frame(master=main,relief='RAISED',borderwidth=5)
log=tk.Text(master=big,relief='SUNKEN',height=20,width=25,borderwidth=10,background='white',lmargin1=2,rmargin=2,wrap='CHAR').grid(row=0,column=0)
os.listdir()
big.im=Image.open('...')
cmd=tk.Button(master=bottom,text='Send a Command',command=open_cmd).grid(row=0)
big.grid(row=0)
bottom.grid(row=1)
prevlog=''
while True:
    l=open(flightlog,'r')
    currentlog=''
    currentlog=l.read(os.path.getsize(flightlog))
    if currentlog-prevlog>0:
        log.insert(END,str(set(currentlog.split('\n'))-set(prevlog.split('\n')).pop())+'\n')
        prevlog=currentlog
    time.sleep(1)
main.mainloop()
