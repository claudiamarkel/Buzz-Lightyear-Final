#!/bin/bash
eval "python3 /home/pi/BuzzLightyear/flight.py"
