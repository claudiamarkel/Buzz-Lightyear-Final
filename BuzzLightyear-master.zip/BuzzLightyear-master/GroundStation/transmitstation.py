#This is the general ground station code that should run either when
#the onboard computer starts up or at a time of the user's choosing.
#This code should be running on the computer of the person whose
#Cubesat is currently in orbit.
import time
import tkinter as tk
import os
import serial
import threading
import bluecom as b

portname='COM3' #CHANGE TO YOUR COM PORT
port=serial.Serial(portname)
filepath = "C:/Users/srira/Documents/Github/BuzzData" #filepath to BuzzData
trialname = "JoshLian" #YourName (folder)
trialpath = filepath + "/" + trialname
t = time.strftime("%B%d_%H:%M:%S")

def git_push():
    #will need to check if trialnum is a directory in Photos, intending to do that in GUI code
    try:
        os.chdir('../')
        path=os.getcwd()
        os.chdir(trialpath)
        os.system("git add .")
        os.system('git commit -m \"Added new files in ' + trialname)
        print('made the commit')
        os.system('git pull')
        os.system('git push origin master')
        print('pushed changes')
        os.chdir(path + '/BuzzLightyear')
    except:
        print('Couldn\'t upload to git')

def check_new(fp,before):
    after=os.listdir(fp)
    if before!=after:
        return (set(after) ^ set(before)).pop()
    else:
        time.sleep(1)
        return str(check_new(fp,after).pop())

def log_entry(text):
    l=open(flightlog, 'a+')
    l.write(text + '\n')      #hoping to read this directly off in gui
    l.close()
    git_push()

def download():
    global fileq
    global telem
    fileq=[]
    while True:
        key,name=b.getKeyedData(port)
        if key='f':
            fileq.append(name)
        elif key='t':
            telem=name
def telemetry(): #THREAD 1:
    while True:
        #look for telemetry packet
        if telem!='':
    	    #once received, send ok signal back to pi  @ben assuming that there is no command, idk if this is right syntax
            #b.sendInt(port,1)
    	    #add telemetry packet to log
            log_entry('Latest Telemetry:' + telem)
            #note new telemetry added, reset to initial state
            telem = ''
        time.sleep(1)

def image_receive(): #THREAD 2:
    while True:
        #check if new pictures
        if len(fileq)>0:
		    #run image processing       #also unsure of how to identify image here, whether we should put in Images file
            name=fileq.pop(0)
            imgval=colorimg(name)    #ideally this would save a data file then output name or have it depend on images
	        #upload values from image processing to log
            shutil.move(name,trialpath + "/Images")
            log_entry(name + ' Image Processing Values: '+ imgval)
        time.sleep(1)

def send_command():#THREAD 3:
    cmd=open(commands,'a+')
    pos=cmd.tell()
    for y in cmd:
        prevcmd=cmd.seek(0,0).read()
    cmd.close()
    while True:
        cmd=open(commands,'a+')
            fullcmd=''
        for y in cmd:
            fullcmd=fullcmd+cmd.read()
        if fullcmd-prevcmd>0:  #check for new commands
            #read from commands file
    		#send them up to the pi to carry them out
            b.sendCommand(port,str(set(fullcmd.split('\n'))-set(prevcmd.split('\n')).pop()))
            #note that command has been sent
            cmd.write('\nsent\n')
            prevcmd = fullcmd + '\nsent\n'  #reset previous file for comparison
        cmd.close()
        time.sleep(.5)

flightlog = "flightlog:" + t + '.txt'
commands = "commands:" + t + '.txt'

port.write(42) #sync up communications
#create new log of flight
log=open(flightlog, 'w+')
log.write(t + " FLIGHT LOG\nCubesat Owner: " + trialname "\n-------START OF FLIGHT LOG-------\n")
log.close()
shutil.move(flightlog, trialpath + "/Logs")

#create new commands file of flight
cmds=open(commands, 'w+')
cmds.write(t + " COMMANDS LIST\nCubesat Owner: " + trialname "\n-------START OF COMMANDS LIST-------\n")
cmds.close()
shutil.move(commands, trialpath + "/Commands")
#upload log and commands to github
git_push()
log=open(flightlog,'a+')
#TEST CODE
#test connection
log_entry('Communications GO')
#test IMU
log_entry('ADCS GO')
#test camera
log_entry('Imaging GO\nALL SYSTEMS GO\n'')
#GROUND STATION READY
lod=threading.Thread(target=download())
tel=threading.Thread(target=telemetry())
img=threading.Thread(target=image_receive())
cmd=threading.Thread(target=send_command())
lod.start()
tel.start()
img.start()
cmd.start()
#time.sleep(600)
#tel.exit()
#img.exit()
#cmd.exit()
#lod.exit()
