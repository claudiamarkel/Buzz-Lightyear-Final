import time
import cv2
import math
import numpy as np
import matplotlib.pyplot as plt

def colorimg(imagefile):
    frame = cv2.imread(imagefile) # Read file

    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV) # Convert to HSV colorspace

    # Bounds of color detection in HSV
    lower_blue = (110,120,75)
    upper_blue = (130,255,255)
    lower_green = (45,40,10) 
    upper_green = (100,255,255)

    lower_red = (0,80,100) 
    upper_red = (10,255,255)
    lower_pink = (165,80,100)
    upper_pink = (180,255,255)

    #Creates mask of only colors within bounds
    mask_blue = cv2.inRange(hsv, lower_blue, upper_blue)
    mask_green = cv2.inRange(hsv, lower_green, upper_green)
    mask_red = cv2.inRange(hsv, lower_red, upper_red)
    mask_pink = cv2.inRange(hsv, lower_pink, upper_pink)
    mask_red_full = mask_red + mask_pink

    Blue = cv2.bitwise_and(frame, frame, mask = mask_blue)
    Green = cv2.bitwise_and(frame, frame, mask = mask_green)
    Red = cv2.bitwise_and(frame, frame, mask = mask_red_full)
    Masks = [Blue, Green, Red]
    Colors = ['Blue', 'Green', 'Red']
    totalplastic = 0.0
    area_sum = [0,0,0]
    result = []
    # Repeating for each color
    for i in range(3):
        
    #   Convert to Grayscale
        imgray = cv2.cvtColor(cv2.cvtColor(Masks[i], cv2.COLOR_HSV2RGB), cv2.COLOR_RGB2GRAY)
#         cv2.imshow("Grayscale", imgray)
    #   Find contours between 0 and gray pixels
        contours, hierarchy = cv2.findContours(imgray,
            cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2:]
    #       Different versions of cv2 return different amounts of values by cv2.findContours.
    #       Using [-2:] will always take the last two values, which are (contours, hierarchy) in both versions.
    #   Counting valid contours
        numbercnt = 0
        data_list = [0,0,0]
        area_sum[i] = 0.0
        resolution = imgray.shape
        resx,resy = resolution
        for cnt in contours:
            rect = cv2.minAreaRect(cnt)
            box = cv2.boxPoints(rect)
            box = np.int0(box)
    #       Creating smallest rectangle bounds
            area = cv2.contourArea(cnt)
    #       Converting image area into calculated distance
            if resx/resy >= 3280/2464:
                true_area = area * np.power((.368 * 80 /.304/resx),2)
            else:
                true_area = area * np.power((.276 * 80 /.304/resy),2)
            
            if 100 > true_area > 1:
                img = cv2.drawContours(imgray,[box],0,(255,40,100),1)
                numbercnt += 1
                sidelength = math.sqrt(true_area)
                
                if true_area < 6.5:
                    data_list[0] += 1
                elif true_area < 40:
                    data_list[1] += 1
                else:
                    data_list[2] += 1
#                 print('Contour ' + str(numbercnt) + ':')
#                 print('Area: ' + str(true_area))
#                 print('Side length: ' + str(sidelength))
                area_sum[i] += area
#                 cv2.imshow('Contours', img)
        
        totalplastic += area_sum[i]/(resx*resy)
#         cv2.waitKey(0)
#         cv2.destroyAllWindows()
        result.append(Colors[i])
        result.append(data_list)
        result.append(str(100*area_sum[i]/(resx*resy)))
    for j in [2,5,8]:
        result[j] = str(round(float(result[j])/totalplastic,2)) + "%"
    result.append('Total plastic percentile : ' + str(round(100*totalplastic,2)) + '%')
    return(result)

#    Given an image, will return 10 Values in a list, where each color (Blue, Green, and Red)
# will be followed by a list of its sizes ([1,1,1] for 1 small, medium, and large piece respec
# -tively. For example, [1,0,2] represents 1 small, 0 medium, and 2 large pieces.) and then with
# its percentile of plastic compared to total plastic. The 10th value gives the total percent
# of plastic detected in the picture.
