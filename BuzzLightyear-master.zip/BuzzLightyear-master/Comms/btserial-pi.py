port = "/dev/rfcomm0"

import os
import serial
import time
import math

import bluecom as b

# ===== CONNECTION =====

#os.system("sudo rfcomm release all")
#pipe = os.popen("sudo rfcomm watch "+port)
print('Waiting for connection...')
#print(pipe.read())
#print("test")
s = serial.Serial(port)
print('Connected on '+s.name)

# ==== USER CODE =====

while True:
	b.sendKeyedFile(s, "btserial-pi.py")
	time.sleep(1)
	break

