import time
import board
import busio
import adafruit_fxos8700
import adafruit_fxas21002c
import numpy
import math
#create arrays to store acceleration values and deviations

accel = []
dev = []

i2c = busio.I2C(board.SCL, board.SDA)
sensor = adafruit_fxasfxos8700.fxos8700(i2c)

while True:
        time.sleep(2)
        accel_x, accel_y, accel_z = sensor.accelerometer
        accel_resultant = math.sqrt(accel_x**2 +  accel_y**2 + accel_z**2)
        accel.append(accel_resultant)
        dev.append(abs(accel_resultant - 9.8))
        if len(accel) == 5:
                max = max(dev)
                print('Precision: ')
                print(max / 9.8)
                accel.clear()
                dev.clear()
