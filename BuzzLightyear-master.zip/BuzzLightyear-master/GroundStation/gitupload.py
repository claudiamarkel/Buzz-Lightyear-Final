#This takes a photo input along with image processing data
#and uploads it to github.

#Joshua Lian
#07.20.2020

#import libraries
import time
from git import Repo
import os

#filepath is path to get to BuzzLightyear Directory, trialname is name of your folder within BuzzLightyear
def git_push():
    #will need to check if trialnum is a directory in Photos, intending to do that in GUI code
    try:
        filepath= 'C:/Users/srira/Documents/Github/BuzzData'#FILEPATH ENDING IN YOUR BuzzLightyear FOLDER
        trialname='JoshLian' #FirstLast (names your specific folder in BuzzLightyear/Runs)
        os.system("cd " + filepath)
        os.system("git add " + trialname)
        os.system('git commit -m \"Added new files in ' + trialname)
        os.system('git pull')
        os.system('git push origin master')
    except:
        print('Couldn\'t upload to git')
git_push()
