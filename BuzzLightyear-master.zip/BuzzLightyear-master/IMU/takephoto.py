import os
import time

FRAMES = 18
TIMEBETWEEN = 10

frameCount = 0
while frameCount < FRAMES:
    imageNumber = str(frameCount).zfill(7)
    os.system("raspistill -o image%s.jpg"%(imageNumber))
    frameCount += 1
    time.sleep(TIMEBETWEEN - 10) #Takes roughly 10 seconds to take a picture
