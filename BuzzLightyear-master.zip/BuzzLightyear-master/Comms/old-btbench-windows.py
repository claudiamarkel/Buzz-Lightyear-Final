import os
import serial
import time
import math

import bluecom as b
	
# ===== CONNECTION =====

s = serial.Serial("COM6")
print('Connected on '+s.name)

# ==== USER CODE =====

for i in range(17):
	b.getFile(s, "bench.txt")
print("returning...")

for i in range(17):
	b.sendFile(s, "bench.txt")

