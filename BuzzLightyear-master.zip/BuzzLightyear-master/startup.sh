#!/bin/bash
eval "bt-agent -c NoInputNoOutput &"
eval "rfcomm watch hci0 0 /home/pi/BuzzLightyear/btstart.sh &"

sleep 1000
