import time
import board
import busio
import adafruit_fxos8700
import adafruit_fxas21002c
import numpy
import math

gyro = []
dev = []

i2c = busio.I2C(board.SCL, board.SDA)
sensor = adafruit_fxas21002c.FXAS21002c(i2c)

while True:
        time.sleep(2)
#collect gyro data and find resultant
        gyro_x, gyro_y, gyro_z = sensor.gyroscope
        gyro_resultant = math.sqrt(gyro_x**2 +  gyro_y**2 + gyro_z**2)
#add data and deviation to array        
        gyro.append(gyro_resultant)
        dev.append(abs(gyro_resultant - 0.0))
#after 5 times, determine precision based on largest deviation
        if len(gyro) == 5:
                max = max(dev)
                print('Precision: ')
                print(max / 9.8)
                gyro.clear()
                dev.clear()
