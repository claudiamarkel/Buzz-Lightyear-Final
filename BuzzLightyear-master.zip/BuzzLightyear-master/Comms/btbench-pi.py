port = "/dev/rfcomm0"

import serial
import time

import bluecom as b

# ===== CONNECTION =====


print('Waiting for connection...')
s = serial.Serial(port)
print('Connected on '+s.name)
b.getNext(s)

# ==== USER CODE =====

print("RFComm datalink benchmark")
print("1M send...")
zero = time.time()
for i in range(17):
	b.sendFile(s, "bench.txt")
	print(i*59921)
print("Data rate: "+str((59921*17)/(time.time()-zero)))

print("1M recieve...")
zero = time.time()
for i in range(17):
	b.getFile(s, "bench.txt")
	print(i*59921)
print("Data rate: "+str((59921*17)/(time.time()-zero)))
