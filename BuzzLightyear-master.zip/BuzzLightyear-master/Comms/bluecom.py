import os
import serial
import time
import math

def getNext(s):
	while s.in_waiting == 0: pass
	return s.read()[0]
def getInt(s, precision=4):
	out = 0
	for i in range(precision):
		out *= 256
		out += getNext(s)
	return out
def getString(s):
	length = getInt(s)
	byt = s.read(length)
	return str(byt, "utf-8")
def getFile(s, path, buf=2048):
	size = getInt(s)
	text = b''
	while size > buf:
		while s.in_waiting < buf: pass
		text += s.read(buf)
		size -= buf 
	while s.in_waiting < size: pass
	text += s.read(size)
	f = open(path, "wb")
	f.write(text)
	f.close()
def sendInt(s, val, precision=4):
	out = b''
	for i in range(precision):
		out = bytes([val % 256]) + out; # push at the beginning of the string
		val = math.floor(val/256)
	s.write(out)
def sendString(s, string):
	sendInt(s, len(string))
	s.write(bytes(string, "utf-8"))
def sendFile(s, path, buf=2048):
	global time
	start = time.time()
	f = open(path, "rb")
	text = f.read()
	sendInt(s, len(text))
	while len(text) > buf:
		s.write(text[0:buf])
		text = text[buf:]
	s.write(text)
#	print(time.time()-start)

def sendKeyedFile(s, location):
	s.write(b'f')
	sendString(s, location)
	sendFile(s, location)

def sendCommand(s, command):
	s.write(b'b')
	sendString(s, command)

def sendKeyedTelem(s, angle):
	global time
	s.write(b't')	
	sendInt(s, int(time.time()))
	sendInt(s, int(angle))

def getKeyedData(s):
	global time
	key = chr(getNext(s))
	out = ""
	if key == 'f':
		filename = getString(s)
		print("Receiving file "+filename)
		start = time.time()
		getFile(s, filename)
		out = filename
	elif key == 'b':
		out = getString(s)
	elif key == 't':
		time = getInt(s)
		angle = getInt(s)
		out = str(time)+','+str(angle)
	return (key, out)
