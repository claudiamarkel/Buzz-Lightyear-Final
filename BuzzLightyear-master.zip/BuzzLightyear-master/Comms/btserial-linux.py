import os
import serial
import time
import math

import bluecom as b
	
# ===== CONNECTION =====

s = serial.Serial("/dev/rfcomm0")
print('Connected on '+s.name)
s.write(1)

# ==== USER CODE =====

while True:
	print("waiting...")
	print(b.getKeyedData(s))
	
s.close()

