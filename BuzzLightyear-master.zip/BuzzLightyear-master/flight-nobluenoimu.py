import os
import re
import time
import math
import serial
import board
import busio

from Camera import CameraScript as camera


#print('Waiting for connection...')
#s = serial.Serial(port)
#print('Connected on '+s.name)

#b.getNext(s)

# send int 1
# ok = recv int
# if not ok: power down
# take test.jpg
# send test.jpg
# ok = recv int
# if not ok: send error, power down
# send imu readings
# ok = recv int
# if not ok: send error, power down

startTime = time.time()


#os.system("touch success.succ")
    
time.sleep(90)
for i in range(18):
    print("science!")
    camera.takepicture("Joshua_Image_" + str(i))
    time.sleep(10)

while time.time() < startTime + 600:
    time.sleep(1)
else:
    exit()

