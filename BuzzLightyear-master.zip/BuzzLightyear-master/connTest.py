from bluecom import *
from picamera import PiCamera
from PIL import Image
import serial
from serial import *
import os
import board
import busio
import adafruit_fxos8700

camera = PiCamera()
camera.capture('/home/pi/Desktop/camcheck.jpg')
print("pic done")

s = serial.Serial('/dev/rfcomm0')

try:
    sendFile(s,'/home/pi/Desktop/camcheck.jpg')
    print("image sent")
except:
    print("image failed")
    os.system('sudo reboot')
    
i2c = busio.I2C(board.SCL, board.SDA)
sensor = adafruit_fxos8700.FXOS8700(i2c)

accelX, accelY, accelZ = sensor.accelerometer

try:
    print([accelX,accelY,accelZ])
    print("IMU operating")
except:
    print("IMU failed")
    os.system('sudo reboot')
