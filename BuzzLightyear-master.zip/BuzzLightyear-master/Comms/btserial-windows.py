import os
import serial
import time
import math

import bluecom as b
	
# ===== CONNECTION =====

s = serial.Serial("COM6") # insert your port here
print('Connected on '+s.name)

# ==== USER CODE =====

while True:
	print(b.getKeyedData(s))
	
s.close()
